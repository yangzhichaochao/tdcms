<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Route::middleware('throttle:200,1')->prefix('/')->group(function () {
    // 首页
    Route::get('/',"Web\IndexController@index");
    // 集团概况 
    Route::get('/bloc',"Web\IndexController@bloc");
    // 新闻中心 
    Route::get('/journalism',"Web\IndexController@journalism");
    // 媒体矩阵 
    Route::get('/media',"Web\IndexController@media");
    // 业务板块 
    Route::get('/business',"Web\IndexController@business");
    // 联系我们 
    Route::get('/me',"Web\IndexController@me");
    
});
