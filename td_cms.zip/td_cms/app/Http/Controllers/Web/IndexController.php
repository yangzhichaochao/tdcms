<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class IndexController extends Controller
{
    public function index(){
        $arr = [];
        return view('web.index',$arr);
    }

    public function bloc(){
        $arr = [];
        return view('web.bloc',$arr);
    }

    public  function journalism(){
        $arr = [];
        return view('web.journalism',$arr);
    }

    public function media(){
        $arr = [];
        return view('web.media',$arr);
    }

    public function business(){
        $arr = [];
        return view('web.business',$arr);
    }

    public function me(){
        $arr = [];
        return view('web.me',$arr);
    }
}
