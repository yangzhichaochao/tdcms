<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>太逗科技集团</title>
    <link rel="stylesheet" href="./css/index.css">
    <script src="./js/jquery.min.js"></script>
</head>

<body>
    <div class="content">
        <div class="main">
            <header>
                <img src="./image/sy/logo.png" alt="">
                <ul>
                <li><a class="active" href="/">首页</a></li>
                    <li><a href="/bloc">集团概况</a></li>
                    <li><a href="/journalism">新闻中心</a></li>
                    <li><a href="/media">媒体矩阵</a></li>
                    <li><a href="/business">业务板块</a></li>
                    <li><a href="/me">联系我们</a></li>
                </ul>
                <img src="./image/sy/syss.png" alt="">
            </header>
            <img class="jtgk_ban" src="./image/jtgk/group.png" alt="">
            <nav>
                <ul>
                    <li><a class="jtjj active" href="javascript:;">集团简介</a></li>
                    <li><a class="line">|</a></li>
                    <li><a class="zczc" href="javascript:;">总裁致辞</a></li>
                    <li><a class="line">|</a></li>
                    <li><a class="gltd" href="javascript:;">管理团队</a></li>
                </ul>
            </nav>
            <div class="main_img">
                <p class="jtjj">
                    太逗科技集团有限公司于2016年3月份创办，是北京市昌平区人民政府战略合作企业，是国家一级广告资质企业，是国家高新技术企业和中关村高新技术企业，是北京吕梁企业商会常务副会长单位，是北京安徽企业商会副会长单位，是中国广告协会和中国商务广告协会会员单位，是中华文化促进会合作企业。目前，集团是百度、字节、腾讯、快手、京东、阿里等媒体平台的广告签约代理商，建有“太逗智投”全媒体投放平台，客户范围覆盖国潮新零售、教育、保险、金融、社交、工具、房产等领域，初步形成媒体加产品的数字产业格局。<br>&nbsp;&nbsp;围绕让营销简单而美好的使命，太逗科技集团秉承构建全球最大营销机构的宏大愿景，遵循“用结果说话、不断寻求最优解、以奋斗者为本、让伙伴因我而更好”的核心价值观，突破与不断突破，持续夯实业务形态，着力打造具有核心竞争力和国际影响力的新型文化产业集团。
                </p>
                <p class="zczc">
                    <img src="./image/jtgk/zczc.png" alt=""> <br>&nbsp;&nbsp; 随着中国特色社会主义进入新时代，文化事业和文化产业迎来了前所未有的发展机遇，也被时代赋予更多的历史使命。
                    <br>&nbsp;&nbsp;太逗科技集团主动适应经济发展新常态，始终坚持突破和创新的奋斗者精神，以科技的力量赋能营销，在效果上追求品效合一，在营销和科技融合发展、助力品牌实现基业长青的伟大征程中发挥积极作用，为实现“共同富裕”的中国梦不断贡献正能量。 <br>&nbsp;&nbsp;太逗的现在是大家共同创造的辉煌，太逗的未来是我们大家共同梦想的集合。我们要遵循“用结果说话、不断寻求最优解、以奋斗者为本、让伙伴因我而更好”的核心价值观，突破与不断突破，持续夯实业务形态，着力打造具有核心竞争力和影响力的新型文化产业集团。
                </p>
                <p class="gltd">
                    <img src="./image/jtgk/gltd.png" alt=""> <br>&nbsp;&nbsp;
                    <span>张雁 政协临县第十届委员会常务委员，太逗科技集团创始人兼联席总裁 </span> <br>&nbsp;&nbsp;张雁，男，汉族，1986年12月生，山西临县人，无境外永久居留权。2008年参加工作，工商管理硕士。政协临县第十届委员会常务委员、北京吕梁企业商会常务副会长、长江商学院校友、协和医学院校友。历任新华社山西分社实习编辑，大唐电信集团、京东商城总监。2016年起，创办太逗科技集团、湫禾商业，参与创办华意传媒集团、华意恒通科技、弘乐电子股份。2021年，荣获山西省总工会机冶建系统五一劳动奖章。2021年，荣获中国广告协会度公益人物荣誉称号。

                </p>
            </div>
            <footer>
                <img src="./image/jtgk/footer.png" alt="">
            </footer>
            <div class="cor2">
                <!-- <img class="copyright" src="./image/sy/sy1.png" alt=""> -->
                <span>版权所有：北京太逗科技集团有限公司</span>
                <span class="cen">京ICP备：10217400号-15</span>
                <div>
                    <a href="jtgk.html">关于我们</a>
                    <a>|</a>
                    <a href="wzsm.html">网站声明</a>
                    <a>|</a>
                    <a href="wzdt.html">网站地图</a>
                    <a>|</a>
                    <a href="lxwm.html">联系我们</a>
                </div>
            </div>
        </div>
    </div>
</body>
<script>
    $('nav .jtjj').click(function() {
        $('.main_img .jtjj').css('display', 'block')
        $('nav .jtjj').addClass('active')
        $('nav .zczc').removeClass('active')
        $('.main_img .zczc').css('display', 'none')
        $('nav .gltd').removeClass('active')
        $('.main_img .gltd').css('display', 'none')
    })
    $('nav .zczc').click(function() {
        $('.main_img .zczc').css('display', 'block')
        $('nav .zczc').addClass('active')
        $('nav .jtjj').removeClass('active')
        $('.main_img .jtjj').css('display', 'none')
        $('nav .gltd').removeClass('active')
        $('.main_img .gltd').css('display', 'none')
    })
    $('nav .gltd').click(function() {
        $('.main_img .gltd').css('display', 'block')
        $('nav .gltd').addClass('active')
        $('nav .jtjj').removeClass('active')
        $('.main_img .jtjj').css('display', 'none')
        $('nav .zczc').removeClass('active')
        $('.main_img .zczc').css('display', 'none')
    })
</script>

</html>