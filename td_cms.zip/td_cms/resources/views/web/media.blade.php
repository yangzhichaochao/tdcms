<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>太逗科技集团</title>
    <link rel="stylesheet" href="./css/index.css">
    <script src="./js/jquery.min.js"></script>
</head>

<body>
    <div class="content">
        <div class="main">
            <header>
                <img src="./image/sy/logo.png" alt="">
                <ul>
                <li><a class="active" href="/">首页</a></li>
                    <li><a href="/bloc">集团概况</a></li>
                    <li><a href="/journalism">新闻中心</a></li>
                    <li><a href="/media">媒体矩阵</a></li>
                    <li><a href="/business">业务板块</a></li>
                    <li><a href="/me">联系我们</a></li>
                </ul>
                <img src="./image/sy/syss.png" alt="">
            </header>
            <img class="jtgk_ban" src="./image/mtjz/1.png" alt="">
            <div class="mtjz_con">
                <img src="./image/mtjz/2.png" alt="">
            </div>
            <footer>
                <img src="./image/jtgk/footer.png" alt="">
            </footer>
            <div class="cor2">
                <!-- <img class="copyright" src="./image/sy/sy1.png" alt=""> -->
                <span>版权所有：北京太逗科技集团有限公司</span>
                <span class="cen">京ICP备：10217400号-15</span>
                <div>
                    <a href="jtgk.html">关于我们</a>
                    <a>|</a>
                    <a href="wzsm.html">网站声明</a>
                    <a>|</a>
                    <a href="wzdt.html">网站地图</a>
                    <a>|</a>
                    <a href="lxwm.html">联系我们</a>
                </div>
            </div>
        </div>
    </div>
</body>

</html>